g++ main.cpp -lraylib -lGL -lm -lpthread -ldl -lrt -lX11
